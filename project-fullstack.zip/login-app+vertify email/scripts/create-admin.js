require('dotenv').config();
const bcrypt = require('bcryptjs');
const db = require('../src/db');

// Pakai: node scripts/create-admin.js <username> <email> <password>
async function main() {
  const [,, username, email, password] = process.argv;

  if (!username || !email || !password) {
    console.log('Cara pakai: node scripts/create-admin.js <username> <email> <password>');
    process.exit(1);
  }

  const existing = db.prepare('SELECT id FROM users WHERE username = ? OR email = ?').get(username, email);
  if (existing) {
    // Kalau user sudah ada, jadikan admin + verified
    db.prepare('UPDATE users SET role = \'admin\', is_verified = 1 WHERE id = ?').run(existing.id);
    console.log(`User "${username}" sudah ada, sekarang dijadikan admin & terverifikasi.`);
    process.exit(0);
  }

  const passwordHash = await bcrypt.hash(password, 10);
  db.prepare(`
    INSERT INTO users (username, email, password_hash, role, is_verified)
    VALUES (?, ?, ?, 'admin', 1)
  `).run(username, email, passwordHash);

  console.log(`Admin "${username}" berhasil dibuat dan langsung terverifikasi. Silakan login.`);
  process.exit(0);
}

main();
