# Login App (Node.js + Express)

Web login sederhana tapi lengkap:
- Register + Login (username & password, hash pakai bcrypt)
- **Email verifikasi wajib** sebelum bisa login
- Client dashboard (untuk user biasa)
- Admin dashboard (kelola user + verifikasi manual + hapus + ubah role)
- **Logging detail** (Winston) untuk debugging: semua request HTTP, percobaan
  login/register, error dengan stack trace — bisa dilihat langsung di admin
  dashboard atau di folder `logs/`
- Database SQLite lewat modul bawaan Node.js (`node:sqlite`) — file lokal,
  tidak perlu install database server ATAU compiler apa pun (butuh Node.js
  versi 22.5 ke atas)

## 1. Install

```bash
cd login-app
npm install
```

## 2. Konfigurasi

```bash
cp .env.example .env
```

Buka `.env` dan isi minimal `SESSION_SECRET` (string acak bebas).

### Soal email verifikasi (PENTING)
- Kalau kamu **tidak isi** `SMTP_HOST`, aplikasi otomatis pakai akun testing
  **Ethereal** — email tidak masuk ke inbox asli, tapi:
  - Link verifikasi akan tampil di **console/log** (`logs/app-YYYY-MM-DD.log`)
    jadi kamu tetap bisa test alur verifikasi tanpa setting apa-apa.
  - Ada juga "preview URL" Ethereal yang muncul di log untuk melihat tampilan
    emailnya.
- Untuk **produksi / email beneran nyampe**, isi di `.env`, contoh pakai
  Gmail (butuh App Password, bukan password biasa akun Gmail kamu):
  ```
  SMTP_HOST=smtp.gmail.com
  SMTP_PORT=587
  SMTP_SECURE=false
  SMTP_USER=emailkamu@gmail.com
  SMTP_PASS=app-password-16-digit
  SMTP_FROM="App Kamu <emailkamu@gmail.com>"
  ```
  Atau pakai layanan lain (Mailtrap, SendGrid SMTP, dll) — tinggal ganti
  host/port/user/pass sesuai provider.

## 3. Buat akun admin pertama

```bash
npm run create-admin -- admin admin@example.com passwordAdmin123
```
Format: `npm run create-admin -- <username> <email> <password>`
Akun ini otomatis jadi role `admin` dan langsung terverifikasi (tidak perlu
cek email).

## 4. Jalankan

```bash
npm start
```

Lalu buka `http://localhost:3000` (otomatis redirect ke halaman login).

## 5. Alur pemakaian

1. User buka `/register.html`, daftar dengan username/email/password.
2. Sistem kirim email verifikasi (atau, kalau belum setting SMTP, link
   verifikasi muncul di log/console).
3. User klik link verifikasi → status akun jadi `verified`.
4. User baru bisa login di `/login.html`. Kalau belum verifikasi, login akan
   ditolak dan ada tombol "Kirim ulang email verifikasi".
5. User biasa diarahkan ke `/dashboard.html`.
6. User dengan role `admin` diarahkan ke `/admin.html` — di sini admin bisa:
   - Lihat semua user, status verifikasi, role, kapan terakhir login.
   - Verifikasi user secara manual (kalau email bermasalah).
   - Ubah role user jadi admin / user biasa.
   - Hapus user.
   - **Lihat log detail** langsung dari browser (auto-refresh tiap 5 detik
     kalau dicentang) — berguna untuk debugging saat testing.

## Struktur folder

```
login-app/
  server.js              -> entry point
  src/
    db.js                -> setup SQLite + schema tabel users
    logger.js             -> setup Winston (logging ke file & console)
    mailer.js             -> setup nodemailer (kirim email verifikasi)
    middleware/auth.js     -> requireLogin, requireAdmin
    routes/auth.js         -> register, login, verify, resend, logout
    routes/admin.js        -> kelola user & ambil log (khusus admin)
  public/                 -> frontend (HTML/CSS/JS polos, tanpa framework)
    login.html
    register.html
    dashboard.html         -> dashboard client
    admin.html             -> dashboard admin
  scripts/create-admin.js -> bikin akun admin lewat CLI
  data/app.db             -> file database (dibuat otomatis)
  logs/                   -> file log harian + error.log
```

## Catatan keamanan / hal yang perlu disesuaikan sebelum ke produksi

- `express-session` di sini pakai penyimpanan sesi default (in-memory) —
  cukup untuk development/testing, tapi untuk produksi sebaiknya pakai store
  persisten (mis. `connect-sqlite3` atau Redis) supaya sesi tidak hilang
  saat server restart dan bisa scaling.
- Jalankan di belakang HTTPS (reverse proxy Nginx/Caddy) dan set
  `cookie.secure = true` di `server.js` saat sudah pakai HTTPS.
- Ganti `SESSION_SECRET` dengan string acak yang panjang & rahasia.
- Rate limit login sudah ada (20x / 15 menit per IP) — bisa disesuaikan di
  `src/routes/auth.js`.
