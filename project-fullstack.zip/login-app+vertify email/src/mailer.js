const nodemailer = require('nodemailer');
const { logger } = require('./logger');

let transporterPromise = null;
let usingEthereal = false;

async function getTransporter() {
  if (transporterPromise) return transporterPromise;

  transporterPromise = (async () => {
    if (process.env.SMTP_HOST) {
      logger.info('Memakai SMTP asli dari .env', { host: process.env.SMTP_HOST });
      return nodemailer.createTransport({
        host: process.env.SMTP_HOST,
        port: Number(process.env.SMTP_PORT || 587),
        secure: process.env.SMTP_SECURE === 'true',
        auth: process.env.SMTP_USER
          ? { user: process.env.SMTP_USER, pass: process.env.SMTP_PASS }
          : undefined
      });
    }

    // Fallback: akun testing Ethereal (email tidak benar-benar terkirim ke
    // dunia nyata, tapi bisa dilihat previewnya). Ini supaya app tetap
    // "berfungsi" walau belum setting SMTP asli.
    usingEthereal = true;
    const testAccount = await nodemailer.createTestAccount();
    logger.warn('SMTP belum dikonfigurasi, memakai akun Ethereal (mode testing). Link verifikasi juga akan tampil di log.', {
      etherealUser: testAccount.user
    });
    return nodemailer.createTransport({
      host: 'smtp.ethereal.email',
      port: 587,
      secure: false,
      auth: { user: testAccount.user, pass: testAccount.pass }
    });
  })();

  return transporterPromise;
}

async function sendVerificationEmail(to, username, verifyUrl) {
  const transporter = await getTransporter();

  const info = await transporter.sendMail({
    from: process.env.SMTP_FROM || '"No Reply" <no-reply@example.com>',
    to,
    subject: 'Verifikasi akun kamu',
    text: `Halo ${username},\n\nKlik link berikut untuk verifikasi akun kamu:\n${verifyUrl}\n\nLink berlaku 24 jam.`,
    html: `
      <p>Halo <b>${username}</b>,</p>
      <p>Klik tombol di bawah untuk verifikasi akun kamu:</p>
      <p><a href="${verifyUrl}" style="background:#4f46e5;color:#fff;padding:10px 18px;border-radius:6px;text-decoration:none;">Verifikasi Email</a></p>
      <p>Atau salin link ini: <br>${verifyUrl}</p>
      <p>Link berlaku 24 jam.</p>
    `
  });

  logger.info('Email verifikasi dikirim', { to, messageId: info.messageId });

  // Selalu log link verifikasi -> memudahkan debugging & testing tanpa
  // harus buka inbox email sungguhan.
  logger.debug('Link verifikasi (untuk debugging)', { verifyUrl });

  if (usingEthereal) {
    const previewUrl = nodemailer.getTestMessageUrl(info);
    logger.info('Preview email (Ethereal, hanya untuk testing)', { previewUrl });
  }

  return info;
}

module.exports = { sendVerificationEmail };
