const express = require('express');
const db = require('../db');
const { logger, tailLatestLog } = require('../logger');
const { requireLogin, requireAdmin } = require('../middleware/auth');

const router = express.Router();

router.use(requireLogin, requireAdmin);

// Daftar semua user
router.get('/users', (req, res) => {
  const users = db.prepare(`
    SELECT id, username, email, role, is_verified, created_at, last_login FROM users ORDER BY id DESC
  `).all();
  logger.debug('Admin membuka daftar user', { admin: req.session.user.username, total: users.length });
  res.json({ ok: true, users });
});

// Verifikasi manual user (misal SMTP bermasalah, admin bisa paksa verifikasi)
router.post('/users/:id/verify', (req, res) => {
  const { id } = req.params;
  db.prepare('UPDATE users SET is_verified = 1, verification_token = NULL WHERE id = ?').run(id);
  logger.info('Admin memverifikasi user secara manual', { admin: req.session.user.username, targetId: id });
  res.json({ ok: true });
});

// Hapus user
router.delete('/users/:id', (req, res) => {
  const { id } = req.params;
  db.prepare('DELETE FROM users WHERE id = ?').run(id);
  logger.info('Admin menghapus user', { admin: req.session.user.username, targetId: id });
  res.json({ ok: true });
});

// Ubah role user (user <-> admin)
router.post('/users/:id/role', (req, res) => {
  const { id } = req.params;
  const { role } = req.body || {};
  if (!['user', 'admin'].includes(role)) {
    return res.status(400).json({ ok: false, message: 'Role tidak valid.' });
  }
  db.prepare('UPDATE users SET role = ? WHERE id = ?').run(role, id);
  logger.info('Admin mengubah role user', { admin: req.session.user.username, targetId: id, role });
  res.json({ ok: true });
});

// Ambil log terbaru untuk keperluan debugging
router.get('/logs', (req, res) => {
  const lines = Number(req.query.lines || 200);
  const logText = tailLatestLog(lines);
  res.json({ ok: true, log: logText });
});

module.exports = router;
