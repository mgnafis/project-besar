const express = require('express');
const crypto = require('crypto');
const bcrypt = require('bcryptjs');
const rateLimit = require('express-rate-limit');
const db = require('../db');
const { logger } = require('../logger');
const { sendVerificationEmail } = require('../mailer');

const router = express.Router();

const loginLimiter = rateLimit({
  windowMs: 15 * 60 * 1000,
  max: 20,
  standardHeaders: true,
  legacyHeaders: false,
  message: { ok: false, message: 'Terlalu banyak percobaan login. Coba lagi nanti.' },
  handler: (req, res, next, options) => {
    logger.warn('Rate limit login terpicu', { ip: req.ip });
    res.status(options.statusCode).json(options.message);
  }
});

function isValidEmail(email) {
  return /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email);
}

function makeToken() {
  return crypto.randomBytes(32).toString('hex');
}

// ===== REGISTER =====
router.post('/register', async (req, res) => {
  const { username, email, password } = req.body || {};
  logger.debug('Percobaan register', { username, email, ip: req.ip });

  if (!username || !email || !password) {
    return res.status(400).json({ ok: false, message: 'Username, email, dan password wajib diisi.' });
  }
  if (username.length < 3) {
    return res.status(400).json({ ok: false, message: 'Username minimal 3 karakter.' });
  }
  if (!isValidEmail(email)) {
    return res.status(400).json({ ok: false, message: 'Format email tidak valid.' });
  }
  if (password.length < 6) {
    return res.status(400).json({ ok: false, message: 'Password minimal 6 karakter.' });
  }

  const existing = db.prepare('SELECT id FROM users WHERE username = ? OR email = ?').get(username, email);
  if (existing) {
    logger.warn('Register gagal: username/email sudah dipakai', { username, email });
    return res.status(409).json({ ok: false, message: 'Username atau email sudah terdaftar.' });
  }

  try {
    const passwordHash = await bcrypt.hash(password, 10);
    const token = makeToken();
    const expires = Date.now() + 24 * 60 * 60 * 1000; // 24 jam

    const info = db.prepare(`
      INSERT INTO users (username, email, password_hash, verification_token, verification_expires)
      VALUES (?, ?, ?, ?, ?)
    `).run(username, email, passwordHash, token, expires);

    const verifyUrl = `${process.env.APP_URL}/api/auth/verify?token=${token}`;
    await sendVerificationEmail(email, username, verifyUrl);

    logger.info('User baru terdaftar, menunggu verifikasi email', { userId: info.lastInsertRowid, username, email });

    return res.json({
      ok: true,
      message: 'Registrasi berhasil. Silakan cek email untuk verifikasi akun sebelum login.'
    });
  } catch (err) {
    logger.error('Error saat register', { error: err.message, stack: err.stack });
    return res.status(500).json({ ok: false, message: 'Terjadi kesalahan server saat registrasi.' });
  }
});

// ===== VERIFY EMAIL =====
router.get('/verify', (req, res) => {
  const { token } = req.query;
  logger.debug('Percobaan verifikasi email', { token, ip: req.ip });

  if (!token) return res.status(400).send('Token verifikasi tidak ada.');

  const user = db.prepare('SELECT * FROM users WHERE verification_token = ?').get(token);

  if (!user) {
    logger.warn('Verifikasi gagal: token tidak ditemukan', { token });
    return res.status(400).send('Link verifikasi tidak valid atau sudah dipakai.');
  }

  if (user.is_verified) {
    return res.redirect('/login.html?verified=already');
  }

  if (user.verification_expires < Date.now()) {
    logger.warn('Verifikasi gagal: token kedaluwarsa', { userId: user.id });
    return res.status(400).send('Link verifikasi sudah kedaluwarsa. Silakan minta link baru lewat halaman login.');
  }

  db.prepare(`
    UPDATE users SET is_verified = 1, verification_token = NULL, verification_expires = NULL WHERE id = ?
  `).run(user.id);

  logger.info('Email berhasil diverifikasi', { userId: user.id, username: user.username });

  return res.redirect('/login.html?verified=1');
});

// ===== RESEND VERIFICATION =====
router.post('/resend-verification', async (req, res) => {
  const { email } = req.body || {};
  if (!email) return res.status(400).json({ ok: false, message: 'Email wajib diisi.' });

  const user = db.prepare('SELECT * FROM users WHERE email = ?').get(email);

  // Jangan bocorkan apakah email terdaftar atau tidak (best practice keamanan)
  if (!user || user.is_verified) {
    logger.debug('Resend verifikasi diabaikan (user tidak ada / sudah verified)', { email });
    return res.json({ ok: true, message: 'Jika email terdaftar dan belum verifikasi, link baru sudah dikirim.' });
  }

  const token = makeToken();
  const expires = Date.now() + 24 * 60 * 60 * 1000;
  db.prepare('UPDATE users SET verification_token = ?, verification_expires = ? WHERE id = ?').run(token, expires, user.id);

  const verifyUrl = `${process.env.APP_URL}/api/auth/verify?token=${token}`;
  await sendVerificationEmail(user.email, user.username, verifyUrl);

  logger.info('Link verifikasi dikirim ulang', { userId: user.id, email });

  return res.json({ ok: true, message: 'Jika email terdaftar dan belum verifikasi, link baru sudah dikirim.' });
});

// ===== LOGIN =====
router.post('/login', loginLimiter, async (req, res) => {
  const { username, password } = req.body || {};
  logger.debug('Percobaan login', { username, ip: req.ip });

  if (!username || !password) {
    return res.status(400).json({ ok: false, message: 'Username dan password wajib diisi.' });
  }

  const user = db.prepare('SELECT * FROM users WHERE username = ? OR email = ?').get(username, username);

  if (!user) {
    logger.warn('Login gagal: user tidak ditemukan', { username, ip: req.ip });
    return res.status(401).json({ ok: false, message: 'Username atau password salah.' });
  }

  const match = await bcrypt.compare(password, user.password_hash);
  if (!match) {
    logger.warn('Login gagal: password salah', { username, ip: req.ip });
    return res.status(401).json({ ok: false, message: 'Username atau password salah.' });
  }

  if (!user.is_verified) {
    logger.warn('Login ditolak: email belum diverifikasi', { username });
    return res.status(403).json({ ok: false, message: 'Email belum diverifikasi. Cek inbox kamu atau minta kirim ulang.' });
  }

  db.prepare('UPDATE users SET last_login = datetime(\'now\') WHERE id = ?').run(user.id);

  req.session.user = { id: user.id, username: user.username, email: user.email, role: user.role };

  logger.info('Login berhasil', { userId: user.id, username: user.username, role: user.role });

  return res.json({ ok: true, user: req.session.user });
});

// ===== LOGOUT =====
router.post('/logout', (req, res) => {
  const username = req.session.user ? req.session.user.username : null;
  req.session.destroy((err) => {
    if (err) {
      logger.error('Gagal logout', { error: err.message });
      return res.status(500).json({ ok: false, message: 'Gagal logout.' });
    }
    logger.info('Logout berhasil', { username });
    res.clearCookie('connect.sid');
    return res.json({ ok: true });
  });
});

// ===== ME (cek sesi sekarang) =====
router.get('/me', (req, res) => {
  if (!req.session.user) return res.json({ ok: true, user: null });
  return res.json({ ok: true, user: req.session.user });
});

module.exports = router;
