const path = require('path');
const winston = require('winston');
require('winston-daily-rotate-file');

const logDir = path.join(__dirname, '..', 'logs');

// Format log: timestamp | level | message | metadata (json)
const logFormat = winston.format.combine(
  winston.format.timestamp({ format: 'YYYY-MM-DD HH:mm:ss' }),
  winston.format.errors({ stack: true }),
  winston.format.printf(({ timestamp, level, message, stack, ...meta }) => {
    const metaStr = Object.keys(meta).length ? ` | ${JSON.stringify(meta)}` : '';
    return `${timestamp} [${level.toUpperCase()}] ${message}${stack ? `\n${stack}` : ''}${metaStr}`;
  })
);

const fileRotateTransport = new winston.transports.DailyRotateFile({
  filename: path.join(logDir, 'app-%DATE%.log'),
  datePattern: 'YYYY-MM-DD',
  maxFiles: '14d',
  level: process.env.LOG_LEVEL || 'debug'
});

// File terpisah khusus error, memudahkan debugging masalah serius
const errorFileTransport = new winston.transports.File({
  filename: path.join(logDir, 'error.log'),
  level: 'error'
});

const logger = winston.createLogger({
  level: process.env.LOG_LEVEL || 'debug',
  format: logFormat,
  transports: [
    fileRotateTransport,
    errorFileTransport,
    new winston.transports.Console({
      format: winston.format.combine(winston.format.colorize(), logFormat)
    })
  ]
});

// Stream supaya morgan (HTTP request logger) bisa menulis lewat winston
logger.stream = {
  write: (message) => logger.http ? logger.http(message.trim()) : logger.info(message.trim())
};

// Helper: baca N baris terakhir dari file log gabungan hari ini (untuk admin dashboard)
const fs = require('fs');
function tailLatestLog(maxLines = 200) {
  try {
    const files = fs.readdirSync(logDir)
      .filter((f) => f.startsWith('app-') && f.endsWith('.log'))
      .sort();
    if (files.length === 0) return 'Belum ada log.';
    const latest = files[files.length - 1];
    const content = fs.readFileSync(path.join(logDir, latest), 'utf-8');
    const lines = content.split('\n').filter(Boolean);
    return lines.slice(-maxLines).join('\n');
  } catch (err) {
    return `Gagal membaca log: ${err.message}`;
  }
}

module.exports = { logger, tailLatestLog, logDir };
