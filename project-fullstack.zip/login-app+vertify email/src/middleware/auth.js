const { logger } = require('../logger');

function requireLogin(req, res, next) {
  if (req.session && req.session.user) return next();
  logger.warn('Akses ditolak: belum login', { path: req.originalUrl, ip: req.ip });
  return res.status(401).json({ ok: false, message: 'Kamu belum login.' });
}

function requireAdmin(req, res, next) {
  if (req.session && req.session.user && req.session.user.role === 'admin') return next();
  logger.warn('Akses ditolak: bukan admin', {
    path: req.originalUrl,
    ip: req.ip,
    user: req.session && req.session.user ? req.session.user.username : null
  });
  return res.status(403).json({ ok: false, message: 'Khusus admin.' });
}

module.exports = { requireLogin, requireAdmin };
