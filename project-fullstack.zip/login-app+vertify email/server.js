require('dotenv').config();
const path = require('path');
const express = require('express');
const session = require('express-session');
const morgan = require('morgan');

const { logger } = require('./src/logger');
const authRoutes = require('./src/routes/auth');
const adminRoutes = require('./src/routes/admin');
const { requireLogin } = require('./src/middleware/auth');

const app = express();
const PORT = process.env.PORT || 3000;

app.use(express.json());
app.use(express.urlencoded({ extended: true }));

// Log setiap HTTP request secara detail lewat winston
app.use(morgan(':method :url :status :res[content-length] - :response-time ms - IP=:remote-addr', {
  stream: logger.stream
}));

app.use(session({
  secret: process.env.SESSION_SECRET || 'ubah-secret-ini',
  resave: false,
  saveUninitialized: false,
  cookie: {
    httpOnly: true,
    maxAge: 1000 * 60 * 60 * 8 // 8 jam
  }
}));

// Static frontend
app.use(express.static(path.join(__dirname, 'public')));

// API routes
app.use('/api/auth', authRoutes);
app.use('/api/admin', adminRoutes);

// Contoh route terproteksi buat dashboard client (ambil data user login)
app.get('/api/dashboard', requireLogin, (req, res) => {
  res.json({ ok: true, user: req.session.user });
});

// 404 khusus API
app.use('/api', (req, res) => {
  res.status(404).json({ ok: false, message: 'Endpoint tidak ditemukan.' });
});

// Error handler global -> selalu tercatat di log dengan detail (stack trace)
app.use((err, req, res, next) => {
  logger.error('Unhandled error', {
    error: err.message,
    stack: err.stack,
    path: req.originalUrl,
    method: req.method
  });
  res.status(500).json({ ok: false, message: 'Terjadi kesalahan pada server.' });
});

app.listen(PORT, () => {
  logger.info(`Server berjalan di ${process.env.APP_URL || `http://localhost:${PORT}`}`);
});

process.on('unhandledRejection', (reason) => {
  logger.error('Unhandled promise rejection', { reason: reason && reason.stack ? reason.stack : reason });
});
process.on('uncaughtException', (err) => {
  logger.error('Uncaught exception', { error: err.message, stack: err.stack });
});
