# Simple Midtrans Payment Gateway (Sandbox)

Aplikasi Node.js + Express sederhana untuk integrasi payment gateway Midtrans (Sandbox), lengkap dengan:

- **Halaman client** (`/`) — form checkout yang membuka popup Snap Midtrans.
- **Dashboard admin** (`/admin`) — lihat semua transaksi, status, dan **log detail request/response** untuk debugging pembayaran.
- **Webhook notification** (`/api/notification`) — otomatis update status order saat Midtrans mengirim notifikasi.
- **Sync status manual** — tombol di dashboard admin untuk cek status transaksi langsung ke Midtrans (berguna kalau webhook belum sempat masuk).

## 1. Install

```bash
cd midtrans-app
npm install
```

## 2. Konfigurasi

File `.env` sudah diisi otomatis dengan API key sandbox dari screenshot yang kamu kirim:

```
MIDTRANS_MERCHANT_ID=M616118325
MIDTRANS_CLIENT_KEY=Mid-client-Ms7X38yfGGugGFhX
MIDTRANS_SERVER_KEY=Mid-server-WUpHusQEIdi0KIDOCz8ZdJEa
MIDTRANS_IS_PRODUCTION=false

ADMIN_USER=admin
ADMIN_PASSWORD=admin123

PORT=3000
```

⚠️ **Penting soal keamanan:**
- Ini adalah **Server Key sandbox** (mode testing), bukan production — aman untuk development.
- Tapi tetap **jangan commit file `.env` ke repo publik** (sudah masuk `.gitignore`).
- Ganti `ADMIN_USER` / `ADMIN_PASSWORD` sebelum deploy ke mana pun.
- Kalau nanti pindah ke akun Midtrans production, ganti key di `.env` dan set `MIDTRANS_IS_PRODUCTION=true`.

## 3. Jalankan

```bash
npm start
```

Lalu buka:

- Client checkout: http://localhost:3000/
- Admin dashboard: http://localhost:3000/admin (login pakai `ADMIN_USER` / `ADMIN_PASSWORD` di `.env`)

## 4. Tes Pembayaran

1. Buka halaman client, isi form, klik "Bayar Sekarang".
2. Popup Snap Midtrans Sandbox akan muncul.
3. Gunakan [kartu / akun simulasi sandbox Midtrans](https://docs.midtrans.com/docs/testing-payment-on-sandbox) untuk simulasi pembayaran (contoh kartu kredit test: `4811 1111 1111 1114`, CVV `123`, exp bebas tanggal depan).
4. Setelah bayar, cek dashboard admin — status & log akan otomatis update kalau webhook notification sudah dikonfigurasi (lihat langkah 5). Kalau belum, klik tombol **🔁 Sync** di dashboard untuk cek status manual langsung ke Midtrans.

## 5. Setup Webhook Notification (opsional tapi disarankan)

Supaya status order otomatis update tanpa klik "Sync" manual, daftarkan URL notifikasi di dashboard sandbox Midtrans:

1. Buka https://dashboard.sandbox.midtrans.com/
2. Settings → Configuration → **Payment Notification URL**
3. Isi dengan: `https://<domain-publik-kamu>/api/notification`
   - Karena `localhost` tidak bisa diakses Midtrans, pakai tool seperti **ngrok** saat development:
     ```bash
     ngrok http 3000
     ```
     lalu pakai URL ngrok, contoh: `https://abcd1234.ngrok-free.app/api/notification`

## 6. Struktur Project

```
midtrans-app/
├── server.js              # entry point express
├── db.js                  # penyimpanan order + log (file db.json, auto-generated)
├── midtrans.js             # setup client Midtrans (Snap + Core API)
├── routes/
│   ├── checkout.js         # POST /api/checkout -> buat transaksi Snap
│   ├── notification.js     # POST /api/notification -> webhook Midtrans
│   └── admin.js             # GET/POST /api/admin/* -> data untuk dashboard
├── public/
│   ├── index.html / css / js/client.js   # halaman client
│   └── admin/               # dashboard admin (dilindungi basic auth)
└── .env                    # konfigurasi & API key
```

## 7. Debugging Pembayaran

Semua request ke Midtrans, response dari Midtrans, notifikasi webhook, dan error tersimpan sebagai **log per order** di `db.json` dan bisa dilihat lewat dashboard admin (klik "🔍 Detail" di baris order). Tipe log yang dicatat:

- `checkout_request` / `checkout_response` / `checkout_error`
- `notification_received` / `notification_processed` / `notification_error`
- `manual_status_check` / `manual_status_check_error`

Ini memudahkan investigasi kalau ada pembayaran yang statusnya nyangkut atau gagal.
