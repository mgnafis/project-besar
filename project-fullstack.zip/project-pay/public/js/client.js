let midtransConfig = null;

async function loadSnapScript() {
  const res = await fetch('/api/config');
  midtransConfig = await res.json();

  return new Promise((resolve, reject) => {
    const snapSrc = midtransConfig.isProduction
      ? 'https://app.midtrans.com/snap/snap.js'
      : 'https://app.sandbox.midtrans.com/snap/snap.js';

    const script = document.createElement('script');
    script.src = snapSrc;
    script.setAttribute('data-client-key', midtransConfig.clientKey);
    script.onload = resolve;
    script.onerror = reject;
    document.head.appendChild(script);
  });
}

function showStatus(message, type = 'info') {
  const box = document.getElementById('status-box');
  box.textContent = message;
  box.className = `status-box ${type}`;
  box.classList.remove('hidden');
}

document.addEventListener('DOMContentLoaded', async () => {
  try {
    await loadSnapScript();
  } catch (e) {
    console.error('Gagal load Snap.js', e);
    showStatus('Gagal memuat Midtrans Snap.js. Cek koneksi internet.', 'error');
  }

  const form = document.getElementById('checkout-form');
  const payBtn = document.getElementById('pay-btn');

  form.addEventListener('submit', async (e) => {
    e.preventDefault();
    payBtn.disabled = true;
    payBtn.textContent = 'Memproses...';
    showStatus('Membuat transaksi...', 'info');

    const payload = {
      customer_name: document.getElementById('customer_name').value,
      customer_email: document.getElementById('customer_email').value,
      customer_phone: document.getElementById('customer_phone').value,
      item_name: document.getElementById('item_name').value,
      gross_amount: document.getElementById('gross_amount').value,
    };

    try {
      const res = await fetch('/api/checkout', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(payload),
      });
      const data = await res.json();

      if (!res.ok) {
        throw new Error(data.detail || data.error || 'Gagal membuat transaksi');
      }

      showStatus(`Order dibuat: ${data.order_id}. Membuka pembayaran...`, 'info');

      window.snap.pay(data.token, {
        onSuccess: function (result) {
          showStatus('✅ Pembayaran berhasil! Order ID: ' + result.order_id, 'success');
        },
        onPending: function (result) {
          showStatus('⏳ Menunggu pembayaran. Order ID: ' + result.order_id, 'pending');
        },
        onError: function (result) {
          showStatus('❌ Pembayaran gagal. Coba lagi.', 'error');
        },
        onClose: function () {
          showStatus('Kamu menutup popup sebelum menyelesaikan pembayaran.', 'pending');
        },
      });
    } catch (err) {
      console.error(err);
      showStatus('❌ Error: ' + err.message, 'error');
    } finally {
      payBtn.disabled = false;
      payBtn.textContent = 'Bayar Sekarang';
    }
  });
});
