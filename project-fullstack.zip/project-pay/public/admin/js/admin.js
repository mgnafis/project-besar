const ordersBody = document.getElementById('orders-body');
const modal = document.getElementById('detail-modal');
const modalOrderId = document.getElementById('modal-order-id');
const modalSummary = document.getElementById('modal-summary');
const modalLogs = document.getElementById('modal-logs');

function formatDate(iso) {
  if (!iso) return '-';
  const d = new Date(iso);
  return d.toLocaleString('id-ID');
}

function formatCurrency(n) {
  return 'Rp ' + Number(n).toLocaleString('id-ID');
}

async function loadOrders() {
  ordersBody.innerHTML = '<tr><td colspan="9" class="empty">Memuat data...</td></tr>';
  try {
    const res = await fetch('/api/admin/orders');
    const orders = await res.json();

    if (!orders.length) {
      ordersBody.innerHTML = '<tr><td colspan="9" class="empty">Belum ada transaksi.</td></tr>';
      return;
    }

    ordersBody.innerHTML = orders
      .map(
        (o) => `
      <tr>
        <td><code>${o.order_id}</code></td>
        <td>${o.customer_name || '-'}<br/><small>${o.customer_email || ''}</small></td>
        <td>${formatCurrency(o.gross_amount)}</td>
        <td><span class="badge ${o.status}">${o.status}</span></td>
        <td>${o.payment_type}</td>
        <td>${formatDate(o.created_at)}</td>
        <td>${formatDate(o.updated_at)}</td>
        <td>${o.log_count} entri</td>
        <td>
          <button class="action-btn" onclick="openDetail('${o.order_id}')">🔍 Detail</button>
          <button class="action-btn" onclick="syncStatus('${o.order_id}')">🔁 Sync</button>
        </td>
      </tr>
    `
      )
      .join('');
  } catch (err) {
    ordersBody.innerHTML = `<tr><td colspan="9" class="empty">Gagal memuat data: ${err.message}</td></tr>`;
  }
}

async function openDetail(order_id) {
  modal.classList.remove('hidden');
  modalOrderId.textContent = `Order: ${order_id}`;
  modalSummary.innerHTML = 'Memuat...';
  modalLogs.innerHTML = '';

  try {
    const res = await fetch(`/api/admin/orders/${order_id}`);
    const order = await res.json();

    modalSummary.innerHTML = `
      <div><strong>Order ID</strong>${order.order_id}</div>
      <div><strong>Status</strong><span class="badge ${order.status}">${order.status}</span></div>
      <div><strong>Nama</strong>${order.customer_name || '-'}</div>
      <div><strong>Email</strong>${order.customer_email || '-'}</div>
      <div><strong>Jumlah</strong>${formatCurrency(order.gross_amount)}</div>
      <div><strong>Metode Bayar</strong>${order.payment_type || '-'}</div>
      <div><strong>Dibuat</strong>${formatDate(order.created_at)}</div>
      <div><strong>Update Terakhir</strong>${formatDate(order.updated_at)}</div>
      <div><strong>Snap Token</strong><code style="font-size:11px">${order.snap_token || '-'}</code></div>
      <div><strong>Redirect URL</strong><a href="${order.snap_redirect_url}" target="_blank" style="font-size:11px">${order.snap_redirect_url || '-'}</a></div>
    `;

    if (!order.logs || !order.logs.length) {
      modalLogs.innerHTML = '<p style="color:#999;font-size:13px">Belum ada log untuk order ini.</p>';
      return;
    }

    modalLogs.innerHTML = order.logs
      .slice()
      .reverse()
      .map(
        (log) => `
      <div class="log-entry">
        <div class="log-entry-header">
          <span class="log-type ${log.type}">${log.type}</span>
          <span>${formatDate(log.timestamp)}</span>
        </div>
        <pre>${escapeHtml(JSON.stringify(log.data, null, 2))}</pre>
      </div>
    `
      )
      .join('');
  } catch (err) {
    modalSummary.innerHTML = `<p style="color:red">Gagal memuat detail: ${err.message}</p>`;
  }
}

async function syncStatus(order_id) {
  try {
    const res = await fetch(`/api/admin/orders/${order_id}/sync-status`, { method: 'POST' });
    const data = await res.json();
    if (!res.ok) throw new Error(data.detail || data.error);
    alert(`Status disinkron: ${data.transaction_status}`);
    loadOrders();
  } catch (err) {
    alert('Gagal sync status: ' + err.message);
  }
}

function escapeHtml(str) {
  return str
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;');
}

document.getElementById('close-modal').addEventListener('click', () => {
  modal.classList.add('hidden');
});

modal.addEventListener('click', (e) => {
  if (e.target === modal) modal.classList.add('hidden');
});

document.getElementById('refresh-btn').addEventListener('click', loadOrders);

// auto refresh tiap 10 detik
loadOrders();
setInterval(loadOrders, 10000);
