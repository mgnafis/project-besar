const express = require('express');
const router = express.Router();
const { snap } = require('../midtrans');
const { generateOrderId, createOrder, addLog, updateOrder } = require('../db');

// POST /api/checkout
// body: { customer_name, customer_email, customer_phone, gross_amount, item_name }
router.post('/checkout', async (req, res) => {
  try {
    const { customer_name, customer_email, customer_phone, gross_amount, item_name } = req.body;

    const amount = parseInt(gross_amount, 10);
    if (!amount || amount <= 0) {
      return res.status(400).json({ error: 'gross_amount tidak valid' });
    }

    const order_id = generateOrderId();

    const item_details = [
      {
        id: 'ITEM-1',
        price: amount,
        quantity: 1,
        name: item_name || 'Pembayaran',
      },
    ];

    const parameter = {
      transaction_details: {
        order_id,
        gross_amount: amount,
      },
      item_details,
      customer_details: {
        first_name: customer_name || 'Guest',
        email: customer_email || 'guest@example.com',
        phone: customer_phone || '08123456789',
      },
    };

    // simpan order dulu ke DB dengan status pending
    createOrder({
      order_id,
      customer_name,
      customer_email,
      gross_amount: amount,
      item_details,
    });

    addLog(order_id, 'checkout_request', parameter);

    const transaction = await snap.createTransaction(parameter);

    addLog(order_id, 'checkout_response', transaction);

    updateOrder(order_id, {
      snap_token: transaction.token,
      snap_redirect_url: transaction.redirect_url,
    });

    return res.json({
      order_id,
      token: transaction.token,
      redirect_url: transaction.redirect_url,
    });
  } catch (err) {
    const order_id = req.body && req.body.order_id;
    console.error('Checkout error:', err.message);
    if (order_id) {
      addLog(order_id, 'checkout_error', {
        message: err.message,
        raw: err.ApiResponse || err.rawHttpClientData || null,
      });
    }
    return res.status(500).json({
      error: 'Gagal membuat transaksi Midtrans',
      detail: err.message,
    });
  }
});

// GET /api/order-status/:order_id -> untuk client cek status ringan (opsional, dipakai halaman client setelah bayar)
router.get('/order-status/:order_id', (req, res) => {
  const { getOrder } = require('../db');
  const order = getOrder(req.params.order_id);
  if (!order) return res.status(404).json({ error: 'Order tidak ditemukan' });
  res.json({
    order_id: order.order_id,
    status: order.status,
    gross_amount: order.gross_amount,
    updated_at: order.updated_at,
  });
});

module.exports = router;
