const express = require('express');
const router = express.Router();
const { core } = require('../midtrans');
const { getAllOrders, getOrder, updateOrder, addLog } = require('../db');

// GET /api/admin/orders -> list semua order (ringkas)
router.get('/orders', (req, res) => {
  const orders = getAllOrders().map((o) => ({
    order_id: o.order_id,
    customer_name: o.customer_name,
    customer_email: o.customer_email,
    gross_amount: o.gross_amount,
    status: o.status,
    payment_type: o.payment_type || '-',
    created_at: o.created_at,
    updated_at: o.updated_at,
    log_count: o.logs ? o.logs.length : 0,
  }));
  res.json(orders);
});

// GET /api/admin/orders/:order_id -> detail lengkap + semua log (untuk debugging)
router.get('/orders/:order_id', (req, res) => {
  const order = getOrder(req.params.order_id);
  if (!order) return res.status(404).json({ error: 'Order tidak ditemukan' });
  res.json(order);
});

// POST /api/admin/orders/:order_id/sync-status
// Panggil langsung ke Midtrans Core API untuk cek status transaksi terbaru.
// Berguna untuk debugging kalau webhook notification belum/gagal masuk.
router.post('/orders/:order_id/sync-status', async (req, res) => {
  const order_id = req.params.order_id;
  const order = getOrder(order_id);
  if (!order) return res.status(404).json({ error: 'Order tidak ditemukan' });

  try {
    const statusResponse = await core.transaction.status(order_id);
    addLog(order_id, 'manual_status_check', statusResponse);

    updateOrder(order_id, {
      status: statusResponse.transaction_status,
      payment_type: statusResponse.payment_type,
    });

    res.json(statusResponse);
  } catch (err) {
    addLog(order_id, 'manual_status_check_error', {
      message: err.message,
      raw: err.ApiResponse || null,
    });
    res.status(500).json({ error: 'Gagal cek status ke Midtrans', detail: err.message });
  }
});

module.exports = router;
