const express = require('express');
const router = express.Router();
const { core } = require('../midtrans');
const { addLog, updateOrder, getOrder } = require('../db');

// POST /api/notification
// Ini adalah URL yang perlu didaftarkan di:
// Midtrans Dashboard Sandbox -> Settings -> Configuration -> Payment Notification URL
// contoh: https://domain-kamu.com/api/notification
router.post('/notification', async (req, res) => {
  const body = req.body;
  const order_id = body.order_id;

  try {
    // core.transaction.notification() akan memvalidasi signature_key otomatis
    // dan mengembalikan status transaksi yang sudah diparse.
    const statusResponse = await core.transaction.notification(body);

    const {
      order_id: oid,
      transaction_status,
      fraud_status,
      payment_type,
      status_code,
      gross_amount,
      signature_key,
    } = statusResponse;

    addLog(oid, 'notification_received', statusResponse);

    if (!getOrder(oid)) {
      addLog(oid, 'notification_error', {
        message: 'Order tidak ditemukan di database lokal',
      });
      return res.status(404).json({ error: 'Order tidak ditemukan' });
    }

    let newStatus = transaction_status;

    // logika standar mapping status Midtrans
    if (transaction_status === 'capture') {
      if (fraud_status === 'challenge') {
        newStatus = 'challenge';
      } else if (fraud_status === 'accept') {
        newStatus = 'settlement';
      }
    } else if (transaction_status === 'settlement') {
      newStatus = 'settlement';
    } else if (
      transaction_status === 'cancel' ||
      transaction_status === 'deny' ||
      transaction_status === 'expire'
    ) {
      newStatus = transaction_status;
    } else if (transaction_status === 'pending') {
      newStatus = 'pending';
    }

    updateOrder(oid, {
      status: newStatus,
      payment_type,
      last_notification: {
        transaction_status,
        fraud_status,
        status_code,
        gross_amount,
        payment_type,
      },
    });

    addLog(oid, 'notification_processed', {
      new_status: newStatus,
      payment_type,
    });

    return res.status(200).json({ message: 'OK' });
  } catch (err) {
    console.error('Notification error:', err.message);
    if (order_id) {
      addLog(order_id, 'notification_error', {
        message: err.message,
        raw_body: body,
      });
    }
    return res.status(500).json({ error: 'Gagal memproses notifikasi', detail: err.message });
  }
});

module.exports = router;
