const path = require('path');
const low = require('lowdb');
const FileSync = require('lowdb/adapters/FileSync');

const adapter = new FileSync(path.join(__dirname, 'db.json'));
const db = low(adapter);

// default structure
db.defaults({ orders: [] }).write();

function nowISO() {
  return new Date().toISOString();
}

function generateOrderId() {
  const rand = Math.random().toString(36).substring(2, 8).toUpperCase();
  return `ORDER-${Date.now()}-${rand}`;
}

function createOrder(order) {
  const record = {
    order_id: order.order_id,
    customer_name: order.customer_name || '-',
    customer_email: order.customer_email || '-',
    gross_amount: order.gross_amount,
    item_details: order.item_details || [],
    status: 'pending',
    snap_token: null,
    snap_redirect_url: null,
    created_at: nowISO(),
    updated_at: nowISO(),
    logs: [],
  };
  db.get('orders').push(record).write();
  return record;
}

function addLog(order_id, type, data) {
  const order = db.get('orders').find({ order_id }).value();
  if (!order) return null;
  const logEntry = {
    timestamp: nowISO(),
    type,
    data,
  };
  db.get('orders')
    .find({ order_id })
    .get('logs')
    .push(logEntry)
    .write();
  return logEntry;
}

function updateOrder(order_id, patch) {
  db.get('orders')
    .find({ order_id })
    .assign({ ...patch, updated_at: nowISO() })
    .write();
  return db.get('orders').find({ order_id }).value();
}

function getOrder(order_id) {
  return db.get('orders').find({ order_id }).value();
}

function getAllOrders() {
  // newest first
  return db.get('orders').sortBy('created_at').reverse().value();
}

module.exports = {
  db,
  generateOrderId,
  createOrder,
  addLog,
  updateOrder,
  getOrder,
  getAllOrders,
};
