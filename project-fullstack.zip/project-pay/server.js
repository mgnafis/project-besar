require('dotenv').config();
const express = require('express');
const path = require('path');
const morgan = require('morgan');
const basicAuth = require('express-basic-auth');

const checkoutRoutes = require('./routes/checkout');
const notificationRoutes = require('./routes/notification');
const adminRoutes = require('./routes/admin');

const app = express();
const PORT = process.env.PORT || 3000;

app.use(morgan('dev'));
app.use(express.json());
app.use(express.urlencoded({ extended: true }));

// expose client key ke frontend tanpa hardcode di HTML
app.get('/api/config', (req, res) => {
  res.json({
    clientKey: process.env.MIDTRANS_CLIENT_KEY,
    isProduction: process.env.MIDTRANS_IS_PRODUCTION === 'true',
  });
});

// route publik (client checkout + webhook notification)
app.use('/api', checkoutRoutes);
app.use('/api', notificationRoutes);

// proteksi dashboard admin dengan basic auth
const adminAuth = basicAuth({
  users: { [process.env.ADMIN_USER || 'admin']: process.env.ADMIN_PASSWORD || 'admin123' },
  challenge: true,
  realm: 'MidtransAdminDashboard',
});

app.use('/api/admin', adminAuth, adminRoutes);
app.use('/admin', adminAuth, express.static(path.join(__dirname, 'public/admin')));

// static file client (halaman pembayaran)
app.use(express.static(path.join(__dirname, 'public')));

app.listen(PORT, () => {
  console.log(`\n🚀 Server jalan di http://localhost:${PORT}`);
  console.log(`   Client checkout : http://localhost:${PORT}/`);
  console.log(`   Admin dashboard : http://localhost:${PORT}/admin  (user: ${process.env.ADMIN_USER || 'admin'})`);
  console.log(`   Mode Midtrans   : ${process.env.MIDTRANS_IS_PRODUCTION === 'true' ? 'PRODUCTION' : 'SANDBOX'}\n`);
});
