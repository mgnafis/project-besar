# PRD — DBN Baking Center

**Versi:** 1.0
**Tanggal:** 30 Agustus 2026
**Status:** Siap dieksekusi oleh AI coding (Claude Code / Cursor / dll)

---

## 1. Overview

**DBN Baking Center** adalah platform penjualan kelas baking **full online** berbasis web. Peserta membeli akses ke satu atau beberapa kelas baking, membayar via Midtrans, lalu mendapat akses ke materi kelas (PDF, video, foto tutorial) melalui **link Google Drive** yang muncul otomatis di dashboard mereka setelah pembayaran sukses.

**Tujuan:**
- Menjual kelas baking secara online tanpa perlu live session — materi berupa konten Drive yang bisa diakses kapan saja setelah beli.
- Proses dari "lihat kelas" sampai "dapat akses materi" berjalan otomatis, tanpa intervensi admin manual (kecuali refund).

**Target user:** Semua usia, siapa saja yang ingin belajar baking secara mandiri (hobi maupun untuk bekal usaha kecil).

**Platform:** Web app, mobile-first, deploy ke Vercel.

**Referensi kode yang sudah ada** (dipakai sebagai basis, bukan ditulis dari nol):
- `project-pay` → pola integrasi Midtrans Snap (checkout, notification webhook, mapping status transaksi).
- `login-app+verify email` → pola registrasi, hash password, generate & kirim token verifikasi email, resend verification.

> ⚠️ Kedua project di atas pakai penyimpanan file (SQLite, lowdb JSON) dan session berbasis memory. **Ini WAJIB diganti** ke PostgreSQL + JWT karena target deploy adalah Vercel (serverless, filesystem tidak persisten). Detail migrasi ada di Bagian 7 & 8.

---

## 2. Scope

### MVP (Fase 1 — wajib ada saat launch)
- Registrasi + login + verifikasi email wajib (JWT-based)
- Katalog kelas (listing + detail kelas)
- Kuota per kelas, diatur admin saat membuat kelas, otomatis jadi "Penuh" kalau kuota habis
- **Cart**: user bisa checkout beberapa kelas sekaligus dalam satu transaksi
- Pembayaran via Midtrans Snap
- Setelah bayar sukses (settlement) → enrollment otomatis dibuat → muncul di menu **"Kelas Saya"** berisi link Drive per kelas
- Email otomatis: konfirmasi registrasi (verifikasi), konfirmasi pembayaran sukses (berisi daftar link Drive kelas yang dibeli)
- Review/rating kelas (hanya bisa oleh user yang sudah punya enrollment aktif ke kelas tsb)
- Riwayat transaksi di dashboard client
- Ajukan refund → sistem hanya mencatat status "refund requested" + tampilkan link/nomor WA admin untuk proses manual
- Dashboard admin: CRUD kelas (termasuk upload thumbnail, input link Drive, atur kuota), lihat semua transaksi, lihat & tandai refund request

### Fase Lanjutan (Post-MVP, TIDAK dikerjakan dulu)
- Reminder H-1 sebelum "kelas" (kalau nanti ada elemen jadwal/live)
- Sertifikat kelulusan
- Refund otomatis (saat ini manual selamanya sampai ada keputusan lain)
- Moderasi review otomatis / laporan review
- Multi-bahasa
- Notifikasi push/WhatsApp otomatis (saat ini WA admin cuma link manual)

---

## 3. User Flow

### 3.1 Alur Client (Pembeli)
1. Buka landing page → lihat highlight & daftar kelas
2. Klik kelas → lihat detail (deskripsi, harga, kuota tersisa, rating)
3. Klik "Tambah ke Keranjang" (bisa ulangi untuk kelas lain)
4. Buka halaman Cart → review kelas yang mau dibeli → klik "Checkout"
5. Jika belum login → diarahkan ke Register/Login dulu (cart tetap tersimpan)
6. Jika belum verifikasi email → diblok, disuruh cek email / minta kirim ulang
7. Setelah login & verified → klik "Bayar" → sistem generate satu transaksi Midtrans Snap untuk semua item di cart → muncul popup/redirect Snap
8. User bayar di Snap (sandbox/production)
9. Midtrans kirim notification webhook ke server → server validasi signature → update status transaksi
10. Jika `settlement`/`capture` (accept) → sistem otomatis:
    - Buat Enrollment untuk tiap kelas di transaksi tsb
    - Kosongkan cart
    - Kirim email konfirmasi berisi daftar link Drive
11. User buka menu **"Kelas Saya"** → lihat semua kelas yang sudah dibayar + link Drive masing-masing
12. User bisa kasih review/rating untuk kelas yang sudah dimiliki
13. Kalau user mau refund → klik "Ajukan Refund" di riwayat transaksi → status tercatat "refund requested" → tampil link WA admin untuk lanjut manual

### 3.2 Alur Admin
1. Login admin (role-based, sistem auth sama dengan client tapi role=admin)
2. Kelola kelas: tambah kelas baru (judul, deskripsi, harga, kuota, thumbnail, link Drive), edit, nonaktifkan/hapus (soft-delete)
3. Lihat daftar transaksi (filter by status: pending/settlement/cancel/expire/refund_requested)
4. Lihat daftar refund request → setelah selesai diproses manual via WA, admin tandai "sudah ditangani"
5. (Opsional) lihat/hapus review yang tidak pantas

---

## 4. Fitur Detail

### 4.1 Registrasi & Verifikasi Email
- Input: username, email, password (min. 6 karakter)
- Validasi: email format valid, username min. 3 karakter, username/email belum terdaftar
- Setelah submit: password di-hash (bcrypt), generate token verifikasi (crypto random, expire 24 jam), kirim email berisi link verifikasi
- Edge case: email sudah terdaftar tapi belum verified → boleh request resend, jangan bocorkan apakah email valid/tidak ada di response (security best practice, ikuti pola login-app)
- Edge case: token expired → user diarahkan minta link baru

### 4.2 Login/Logout
- Login pakai username **atau** email + password
- Berhasil login → generate JWT (payload: user id, role, email) → simpan di **httpOnly cookie** (bukan localStorage, supaya lebih aman dari XSS)
- Gagal 401 kalau salah password/username, 403 kalau belum verifikasi
- Rate limit percobaan login (reuse pola `express-rate-limit` dari login-app: 20 percobaan / 15 menit)
- Logout → clear cookie JWT

### 4.3 Katalog & Detail Kelas
- List kelas: thumbnail, judul, harga, kuota tersisa, rating rata-rata
- Filter/search sederhana (opsional MVP, boleh skip kalau kelas masih sedikit)
- Detail kelas: deskripsi lengkap, harga, kuota tersisa (badge "Penuh" kalau habis), daftar review

### 4.4 Cart & Checkout Multi-Kelas
- User bisa tambah beberapa kelas ke cart sebelum checkout
- Cart tervalidasi ulang saat checkout: cek tiap kelas masih aktif & kuota masih tersedia (kalau ada yang habis pas mau checkout, kasih notif & keluarkan dari cart)
- Checkout generate **satu order Midtrans** dengan `item_details` berisi semua kelas di cart (reuse pola `checkout.js` dari project-pay, disesuaikan jadi multi-item, bukan single item)
- Order tersimpan status `pending` di DB sebelum redirect ke Snap

### 4.5 Payment (Midtrans Snap)
- Reuse pola `midtrans.js` (init Snap & Core API client) dan `notification.js` (validasi signature via `core.transaction.notification()`, mapping status: `capture`+`accept`→`settlement`, `capture`+`challenge`→`challenge`, `settlement`→`settlement`, `cancel`/`deny`/`expire`→sesuai, `pending`→`pending`)
- Saat status jadi `settlement`: trigger proses enrollment otomatis (lihat 4.6)
- Endpoint `GET /order-status/:order_id` untuk client polling status ringan setelah redirect balik dari Snap

### 4.6 Enrollment & "Kelas Saya"
- Trigger otomatis saat notification masuk dengan status `settlement`
- Untuk tiap kelas dalam order tsb → buat 1 record Enrollment (kalau belum ada, hindari duplikat)
- Menu "Kelas Saya" menampilkan semua Enrollment milik user, masing-masing dengan tombol/link ke Google Drive kelas tsb
- Edge case: kalau payment `pending` terlalu lama atau `expire` → kelas tidak muncul di "Kelas Saya", cukup tampil di riwayat transaksi dengan status jelas

### 4.7 Review & Rating
- Hanya user dengan Enrollment aktif ke kelas tsb yang boleh submit review
- Input: rating 1-5, komentar teks
- 1 user hanya boleh 1 review per kelas (edit review yang sudah ada kalau submit ulang)
- Rating rata-rata kelas dihitung dari semua review aktif

### 4.8 Riwayat Transaksi & Refund
- List semua order milik user beserta status & daftar kelas di dalamnya
- Tombol "Ajukan Refund" muncul untuk order dengan status `settlement` yang belum ada refund request
- Klik tombol → buat record RefundRequest (status `requested`) → tampilkan nomor/link WA admin untuk lanjut manual
- Admin bisa update status RefundRequest jadi `handled_manual` dari dashboard

### 4.9 Dashboard Admin
- CRUD Kelas: judul, slug, deskripsi, harga, kuota, thumbnail (upload ke Cloudinary), link Google Drive, status aktif/nonaktif
- List transaksi + filter status + detail item per transaksi
- List refund request + tombol tandai selesai
- (Opsional) moderasi review: hapus review yang melanggar
- Proteksi: hanya user dengan role `admin` yang bisa akses (middleware `requireAdmin`)

---

## 5. Data Model

```
users
- id (PK)
- username (unique)
- email (unique)
- password_hash
- role            enum('user','admin') default 'user'
- is_verified     boolean default false
- verification_token
- verification_expires
- created_at
- last_login_at

classes
- id (PK)
- title
- slug (unique)
- description
- price           integer (rupiah)
- quota           integer
- thumbnail_url   (Cloudinary URL)
- drive_link      (URL Google Drive)
- is_active       boolean default true
- created_at
- updated_at

orders
- id (PK)
- order_id        (unique, dipakai sbg Midtrans order_id, format ORDER-<timestamp>-<random>)
- user_id (FK -> users)
- status          enum('pending','settlement','challenge','cancel','deny','expire','refund_requested')
- gross_amount    integer
- payment_type
- snap_token
- snap_redirect_url
- created_at
- updated_at

order_items
- id (PK)
- order_id (FK -> orders)
- class_id (FK -> classes)
- price_at_purchase   integer   -- snapshot harga saat beli, jaga2 harga kelas berubah nanti

enrollments
- id (PK)
- user_id (FK -> users)
- class_id (FK -> classes)
- order_item_id (FK -> order_items)
- access_granted_at
- unique(user_id, class_id)   -- cegah duplikat enrollment

reviews
- id (PK)
- class_id (FK -> classes)
- user_id (FK -> users)
- rating          integer (1-5)
- comment         text
- created_at
- updated_at
- unique(class_id, user_id)  -- 1 user 1 review per kelas

refund_requests
- id (PK)
- order_id (FK -> orders)
- user_id (FK -> users)
- status          enum('requested','handled_manual')
- note
- created_at
- updated_at
```

**Catatan kuota:** kuota tersisa dihitung on-the-fly: `quota - COUNT(enrollments WHERE class_id = ?)`. Tidak perlu kolom `quota_sisa` terpisah supaya tidak ada risiko data tidak sinkron.

---

## 6. Desain & UX Guidelines

- **Mobile-first** — desain & test utamanya di viewport HP dulu, baru cek desktop
- **Palet warna**: dominan **putih** & **merah**, aksen **gold/emas**, warna **hitam hanya untuk teks** (jangan dipakai sebagai warna background/section besar)
- Kalau ada file `logo.png` — belum diterima di sesi ini, tolong upload menyusul supaya tone warna final bisa disamakan persis dengan logo. Sementara AI coding boleh pakai palet di atas sebagai acuan.
- Tipografi: pilih font yang hangat/friendly (cocok tema baking), bukan font teknis/kaku
- Komponen kunci yang butuh perhatian desain: card kelas (thumbnail + harga + kuota badge), halaman cart, tombol checkout (jelas & mencolok, pakai warna merah/gold sebagai CTA), menu "Kelas Saya" (harus terasa seperti "reward" setelah beli — rapi, ada ikon/badge per kelas)
- Semua form (register, login, tambah kelas) harus punya validasi & pesan error yang jelas dalam Bahasa Indonesia

---

## 7. Tech Stack

| Layer | Pilihan | Alasan |
|---|---|---|
| Runtime | Node.js (LTS) | Sesuai kedua project referensi |
| Backend framework | Express.js | Reuse langsung struktur route dari project-pay & login-app |
| Templating | EJS (server-side render) | Simpel untuk solo dev, cocok jalan di atas Express |
| Auth | JWT (`jsonwebtoken`) + `bcryptjs`, token di httpOnly cookie | Session-based (punya login-app) tidak jalan di serverless Vercel |
| Database | PostgreSQL (Neon serverless Postgres) | Kompatibel serverless, gratis tier cukup untuk MVP; ganti total dari SQLite/lowdb di kedua project referensi |
| DB driver | `pg` (node-postgres) dengan connection pooling sesuai rekomendasi Neon, atau `@neondatabase/serverless` | Neon serverless driver lebih cocok untuk lingkungan Vercel Functions |
| Image storage | Cloudinary | Gratis tier cukup, tidak butuh disk server |
| Payment | Midtrans Snap (`midtrans-client`) | Reuse langsung dari project-pay, sudah terbukti jalan di sandbox |
| Email | `nodemailer` | Reuse pola dari login-app; **wajib SMTP baru**, jangan pakai kredensial lama yang sudah pernah ter-expose |
| Deploy | Vercel | Sesuai keputusan; backend Express dibungkus jadi serverless function |

---

## 8. Rules & Constraints (Wajib Diikuti AI Coding)

### 8.1 Migrasi dari Project Referensi (PENTING)
- **JANGAN** pakai `node:sqlite` atau `lowdb` sama sekali di project baru — filesystem Vercel tidak persisten. Semua data WAJIB masuk PostgreSQL (Neon).
- **JANGAN** pakai `express-session` dengan MemoryStore — ganti total ke JWT di httpOnly cookie.
- **JANGAN** pakai `winston-daily-rotate-file` (tulis file log ke disk) — cukup `console.log`/`console.error` biasa, Vercel otomatis menangkap sebagai log platform.
- **BOLEH & DIANJURKAN** reuse logic murni (bukan storage-nya) dari:
  - `login-app`: fungsi hash password, generate token verifikasi (`crypto.randomBytes`), fungsi `sendVerificationEmail` (nodemailer), validasi email regex, rate limiter login.
  - `project-pay`: struktur `midtrans.js` (init Snap & Core client), logic mapping status transaksi Midtrans, validasi signature via `core.transaction.notification()`.
- **JANGAN** pakai kredensial SMTP/Gmail App Password yang ada di `.env.example` lama — itu harus dianggap bocor dan tidak dipakai lagi, buat App Password baru.
- Ganti admin auth dari `express-basic-auth` (project-pay) menjadi satu sistem auth JWT yang sama dengan client, dibedakan lewat `role='admin'`.

### 8.2 Struktur Folder (rekomendasi)
```
/api            -> entry point serverless (mis. index.js yang wrap Express app)
/src
  /routes       -> definisi route per fitur (auth.js, classes.js, cart.js, checkout.js, notification.js, admin.js, reviews.js)
  /controllers  -> logic tiap route
  /db           -> koneksi pg pool + query helper per entity
  /middleware   -> requireAuth.js, requireAdmin.js
  /utils        -> mailer.js, token.js, dsb
/views          -> file EJS
/public         -> css/js/img statis
/migrations     -> file SQL untuk bikin schema Postgres
vercel.json
.env.example
```

### 8.3 Testing Sebelum Dianggap Selesai
- Setiap fitur WAJIB ditest secara lokal (`npm run dev`) sebelum ditandai "done" — bukan cuma dibaca kodenya
- Untuk fitur pembayaran: WAJIB ditest end-to-end pakai Midtrans **Sandbox** (checkout → bayar → notification masuk → status ter-update → enrollment muncul) sebelum lanjut ke fitur berikutnya
- Deploy ke Vercel HANYA setelah semua fitur MVP jalan stabil di lokal (sesuai preferensi user: test lokal dulu, baru deploy)

### 8.4 Konvensi
- Penamaan variabel/fungsi JS: camelCase
- Nama kolom database: snake_case
- Nama file route/controller: kebab-case
- Commit message: Conventional Commits (`feat:`, `fix:`, `chore:`, `refactor:`, `docs:`)

### 8.5 Larangan Keras
- **JANGAN** hardcode API key/secret apa pun (Midtrans Server Key, JWT Secret, SMTP password, Database URL, Cloudinary secret) di dalam kode — semua wajib lewat environment variable
- **JANGAN** expose `MIDTRANS_SERVER_KEY` ke frontend/client — hanya `MIDTRANS_CLIENT_KEY` yang boleh publik
- **JANGAN** proses update status transaksi tanpa validasi signature dari Midtrans (`core.transaction.notification()`) — cegah spoofing notification
- **JANGAN** hapus data (kelas, user, transaksi, review) secara permanen dari database tanpa soft-delete/flag dan tanpa konfirmasi eksplisit di UI admin (modal "Yakin ingin menghapus?")
- **JANGAN** menambah dependency besar (ORM berat, framework tambahan) tanpa alasan jelas — utamakan tetap ringan karena dimaintain solo

---

## 9. Milestone / Roadmap

**Fase 0 — Setup**
- [ ] Init repo + struktur folder + `.env.example`
- [ ] Setup Neon Postgres + jalankan migration schema awal (semua tabel di Bagian 5)
- [ ] Setup koneksi DB reusable (pool/connection helper)

**Fase 1 — Auth**
- [ ] Endpoint register (hash password + generate token + kirim email verifikasi)
- [ ] Endpoint verify token
- [ ] Endpoint resend verification
- [ ] Endpoint login → generate JWT → set httpOnly cookie
- [ ] Middleware `requireAuth` & `requireAdmin`
- [ ] Endpoint logout
- [ ] Test lokal: register → cek email → verify → login → akses halaman protected

**Fase 2 — Manajemen Kelas (Admin)**
- [ ] CRUD kelas + upload thumbnail ke Cloudinary + input link Drive + set kuota
- [ ] Kelas otomatis "Penuh" kalau kuota habis
- [ ] Test lokal CRUD kelas end-to-end

**Fase 3 — Katalog & Cart (Client)**
- [ ] Landing page + listing kelas (EJS, mobile-first, palet warna brand)
- [ ] Halaman detail kelas
- [ ] Tambah ke cart (multi-kelas), halaman cart
- [ ] Validasi ulang kuota saat checkout
- [ ] Test lokal alur browsing → cart

**Fase 4 — Payment**
- [ ] Endpoint checkout (multi-item Snap transaction, reuse pola project-pay)
- [ ] Endpoint notification webhook (validasi signature + mapping status)
- [ ] Trigger otomatis pembuatan Enrollment saat `settlement`
- [ ] Email konfirmasi pembayaran + daftar link Drive
- [ ] Test lokal FULL pakai Midtrans Sandbox

**Fase 5 — Dashboard Client**
- [ ] Menu "Kelas Saya" (list enrollment + link Drive)
- [ ] Riwayat transaksi + status
- [ ] Fitur ajukan refund (buat RefundRequest + tampilkan kontak WA admin)
- [ ] Form review/rating (khusus user dengan enrollment aktif)
- [ ] Test lokal semua menu client

**Fase 6 — Dashboard Admin Lanjutan**
- [ ] List transaksi + filter status
- [ ] List & update status refund request
- [ ] (Opsional) moderasi review
- [ ] Test lokal

**Fase 7 — Persiapan Deploy Vercel**
- [ ] Bungkus Express app jadi serverless-compatible (`/api/index.js`)
- [ ] Setup `vercel.json` (routing ke Express + static files)
- [ ] Pindahkan semua secret ke Vercel Environment Variables
- [ ] Update Payment Notification URL Midtrans ke domain Vercel
- [ ] Test end-to-end di Vercel **preview deployment** sebelum ke production

**Fase 8 — QA Akhir & Go-Live**
- [ ] Regression test manual seluruh fitur MVP
- [ ] Cek tampilan di device HP asli (bukan cuma emulator)
- [ ] Ganti semua kredensial default (JWT secret, admin password awal, SMTP) sebelum go-live
- [ ] Go-live

---

## 10. Definition of Done

Sebuah fitur dianggap **selesai** jika memenuhi semua ini:

1. Berjalan tanpa error di lokal (`npm run dev`) dengan data nyata dari Postgres (bukan data dummy hardcoded)
2. Semua input tervalidasi, pesan error jelas & dalam Bahasa Indonesia untuk end-user
3. Tidak ada secret/API key hardcoded — semua lewat `.env` / Environment Variables
4. Endpoint yang butuh login/role tertentu benar-benar tertolak kalau diakses tanpa auth yang sesuai (sudah dicoba manual)
5. Tampilan sudah dicek di viewport mobile dan sesuai palet warna brand (putih-merah-gold, teks hitam)
6. Khusus fitur yang menyentuh Midtrans: sudah ditest end-to-end di sandbox sampai status transaksi ter-update dengan benar
7. Perubahan data penting (hapus/nonaktifkan) sudah ada konfirmasi di UI sebelum eksekusi
8. Sudah di-commit dengan pesan yang jelas mengikuti Conventional Commits

---

*Dokumen ini dibuat berdasarkan hasil klarifikasi dengan pemilik project dan analisis langsung terhadap 2 project referensi (`project-pay`, `login-app+verify email`) yang sudah ada. AI coding yang mengeksekusi PRD ini WAJIB membaca Bagian 7 & 8 dengan cermat sebelum mulai menulis kode, karena ada penyesuaian arsitektur signifikan dari kedua project referensi tersebut.*
